(function() {
    'use strict';

    angular.module('myApp').controller('TimerController', ['$interval', function($interval) {

        var vm = this;

        vm.width = "0%";
        var stop,counter = {};

        vm.startTimer = function() {
          if (!angular.isDefined(stop)) {
            var time = vm.time.split(':');
            counter.hours = parseInt(time[0]);
            counter.min = parseInt(time[1]);
            counter.sec = parseInt(time[2]);
            counter.totalSec = counter.sec + (counter.min * 60) + (counter.hours * 60 * 60);

            if ( angular.isDefined(stop) ) return;
            var secCount = 0;
            stop = $interval(function() {
              secCount++;
              if(counter.sec % 5 === 0){
                vm.width = Math.round(secCount / counter.totalSec * 100) + '%';
              }

              if (counter.sec === -1) {
                counter.sec = 59;
                counter.min--;
              }

              if (counter.min === -1) {
                counter.min = 59;
                counter.hours--;
              }

              if (counter.hours === 0 && counter.min === 0 && counter.sec === 0){
                vm.time = "00:00:00";
                vm.width = "100%";
                vm.stopFight();
              }
              else {
                vm.time = (counter.hours < 10 ? '0'+counter.hours : counter.hours)+ ':' +(counter.min < 10 ? '0'+counter.min : counter.min)+ ':' +(counter.sec < 10 ? '0'+counter.sec-- : counter.sec--);
              }
            }, 1000);
          }
      };

      vm.stopFight = function() {
        if (angular.isDefined(stop)) {
          $interval.cancel(stop);
          stop = undefined;
        }
      };

    }]);

})();
