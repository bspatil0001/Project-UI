(function(){
  'use strict';

  angular.module('myApp',[]);

})();
